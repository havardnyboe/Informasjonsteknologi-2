window.onload = () => { // en lytter til knappene på siden
    document.querySelector('.neste').onclick = nesteBilde;
    document.querySelector('.forrige').onclick = forrigeBilde;
}

const divBilder = document.querySelector('.bilder');
let bilder = ['img/bird.jpg', 'img/ducks.jpeg', 'img/panda.jpg']; // liste med bildene 
let settGjennom = [bilder[0]] // liste med bildene som er sett
let bildeNr = 0;

setInterval(() => {
    nesteBilde();
}, 5000);

function nesteBilde() {
    if (bildeNr >= bilder.length - 1) {
        bildeNr = 0;
    } else {
        bildeNr++;
        settGjennom.push(bilder[bildeNr]); // putter bildet som er sett i listen
    }
    divBilder.innerHTML = `<img src="${bilder[bildeNr]}" width="500">`;
    // sjekkSettGjennom();
}

function forrigeBilde() {
    if (bildeNr <= 0) {
        bildeNr = bilder.length - 1;
    } else {
        bildeNr--;
        settGjennom.push(bilder[bildeNr]); // putter bildet som er sett i listen
    }
    divBilder.innerHTML = `<img src="${bilder[bildeNr]}" width="500">`;
    // sjekkSettGjennom();
}

// Dette var et forsøk på oppg 6 og 7:

// function sjekkSettGjennom() {
//     let settAnt = 0;
//     bilder.forEach(i => {
//         settGjennom.forEach(j => {
//             if (i == j) {
//                 settAnt++
//                 console.log(settAnt)
//             };
//             if (settAnt == 2) {
//                 alert('Du har sett dette bilde før, prøv å utvide din bildesmak.')
//                 settAnt = 0;
//             }
//         });
//     });
// }